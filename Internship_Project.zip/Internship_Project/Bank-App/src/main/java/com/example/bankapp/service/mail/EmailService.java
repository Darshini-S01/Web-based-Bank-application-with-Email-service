package com.example.bankapp.service.mail;


import com.example.bankapp.model.Account;
import java.math.BigDecimal;

public interface EmailService {
    void sendWelcomeEmail(Account account);
    void sendTransactionNotificationEmail(Account recipientAccount, Account senderAccount, BigDecimal amount, String transactionReference);
}