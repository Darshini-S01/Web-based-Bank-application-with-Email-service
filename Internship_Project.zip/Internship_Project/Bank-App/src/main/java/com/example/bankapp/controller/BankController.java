package com.example.bankapp.controller;

import com.example.bankapp.dto.AccountDto; // Import AccountDto
import com.example.bankapp.model.Account;
import com.example.bankapp.model.Transaction; // Assuming Transaction might be needed in model sometimes
import com.example.bankapp.service.AccountService;
import jakarta.validation.Valid; // For validating the DTO
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication; // For getting current user
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails; // For @AuthenticationPrincipal
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult; // To hold validation errors
import org.springframework.validation.FieldError; // For adding custom field errors
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // For flash messages

import java.math.BigDecimal;
import java.util.List; // For transaction history

@Controller
public class BankController {

    private final AccountService accountService;

    @Autowired
    public BankController(AccountService accountService) {
        this.accountService = accountService;
    }

    private Account getCurrentUserAccount() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || "anonymousUser".equals(authentication.getPrincipal())) {
            return null; // Or throw exception if user must be authenticated
        }
        String username = authentication.getName();
        return accountService.findByUsername(username);
    }

    @GetMapping("/")
    public String home() {
        // If user is authenticated, redirect to dashboard, else to login
        Account currentUser = getCurrentUserAccount();
        if (currentUser != null) {
            return "redirect:/dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) { // Should not happen if security is set up correctly
            return "redirect:/login";
        }
        Account account = accountService.findByUsername(userDetails.getUsername());
        model.addAttribute("account", account);
        // Add empty transaction object for form binding if deposit/withdraw forms are on dashboard
        // model.addAttribute("transaction", new Transaction()); // Example
        if (!model.containsAttribute("successMessage")) { // Avoid overwriting flash attributes
            model.addAttribute("successMessage", null);
        }
        if (!model.containsAttribute("errorMessage")) {
            model.addAttribute("errorMessage", null);
        }
        return "dashboard";
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        // Pass an empty AccountDto to the form for data binding
        if (!model.containsAttribute("accountDto")) { // Avoid overwriting if redirected with errors
            model.addAttribute("accountDto", new AccountDto());
        }
        return "register";
    }

    @PostMapping("/register")
    public String registerAccount(@Valid @ModelAttribute("accountDto") AccountDto accountDto,
                                  BindingResult bindingResult, // Must come right after @Valid bean
                                  Model model,
                                  RedirectAttributes redirectAttributes) {

        // Custom validation for uniqueness (can also be done with custom validator)
        if (!bindingResult.hasFieldErrors("username") && accountService.DtoByUsernameExists(accountDto.getUsername())) {
            bindingResult.addError(new FieldError("accountDto", "username", "Username '" + accountDto.getUsername() + "' is already taken."));
        }
        if (!bindingResult.hasFieldErrors("email") && accountService.DtoByEmailExists(accountDto.getEmail())) {
            bindingResult.addError(new FieldError("accountDto", "email", "Email '" + accountDto.getEmail() + "' is already registered."));
        }

        if (bindingResult.hasErrors()) {
            // If there are validation errors, return to the registration form
            // The th:object="${accountDto}" and th:field in HTML will repopulate fields
            // and th:errors will display errors.
            model.addAttribute("accountDto", accountDto); // Ensure DTO is in model
            return "register";
        }

        try {
            accountService.registerAccount(accountDto);
            redirectAttributes.addFlashAttribute("successMessage", "Registration successful! Welcome! Please check your email.");
            return "redirect:/login?registrationSuccess"; // Redirect to login with a success indicator
        } catch (IllegalArgumentException e) { // Catch specific exceptions from service
            // This can be used for errors not caught by bean validation (e.g., race conditions for uniqueness)
            // Or more general errors during the registration process itself.
            // For uniqueness, we already added to bindingResult. This is a fallback.
            model.addAttribute("accountDto", accountDto); // Keep user data in form
            model.addAttribute("errorMessage", e.getMessage()); // General error message for the form
            return "register";
        } catch (RuntimeException e) { // Catch any other unexpected errors
            model.addAttribute("accountDto", accountDto);
            model.addAttribute("errorMessage", "An unexpected error occurred during registration. Please try again.");
            return "register";
        }
    }
    @GetMapping("/login")
    public String loginPage(Model model, @RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "logout", required = false) String logout,
                            @RequestParam(value = "registrationSuccess", required = false) String registrationSuccess) {
        if (error != null) {
            model.addAttribute("errorMessage", "Invalid username or password.");
        }
        if (logout != null) {
            model.addAttribute("successMessage", "You have been logged out successfully.");
        }
        if (registrationSuccess != null) {
            // This message might be better handled by a flash attribute from register if redirecting
            // For now, if we have `successMessage` flash attribute from register, it will be used.
            // If not, this will add a message.
            if (!model.containsAttribute("successMessage")) {
                model.addAttribute("successMessage", "Registration successful! Please login.");
            }
        }
        return "login";
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam BigDecimal amount,
                          @AuthenticationPrincipal UserDetails userDetails,
                          RedirectAttributes redirectAttributes) {
        if (userDetails == null) return "redirect:/login";
        Account account = accountService.findByUsername(userDetails.getUsername());
        try {
            accountService.deposit(account, amount);
            redirectAttributes.addFlashAttribute("successMessage", "Deposit successful!");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/dashboard";
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam BigDecimal amount, // Changed name from deposit to withdraw
                           @AuthenticationPrincipal UserDetails userDetails,
                           Model model, // Keep Model for errors directly on dashboard
                           RedirectAttributes redirectAttributes) {
        if (userDetails == null) return "redirect:/login";
        Account account = accountService.findByUsername(userDetails.getUsername());
        try {
            accountService.withdraw(account, amount);
            redirectAttributes.addFlashAttribute("successMessage", "Withdrawal successful!");
        } catch (RuntimeException e) { // Catches InsufficientFunds or IllegalArgument
            // Using RedirectAttributes for consistency, but could also set on model for immediate display
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            // If you want to stay on dashboard and show error without full redirect,
            // you'd need to re-populate model attributes for dashboard.
            // For simplicity with PRG pattern, redirecting.
            // model.addAttribute("account", account);
            // model.addAttribute("errorMessage", e.getMessage());
            // return "dashboard";
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/transactions")
    public String transactionHistory(Model model, @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) return "redirect:/login";
        Account account = accountService.findByUsername(userDetails.getUsername());
        List<Transaction> transactions = accountService.getTransactionHistory(account);
        model.addAttribute("transactions", transactions);
        model.addAttribute("account", account); // Also pass account for balance display etc.
        return "transactions";
    }

    @PostMapping("/transfer")
    public String transfer(@RequestParam String toUsername, // @AuthenticationPrincipal was trying to bind Account, let's get it manually
                           @RequestParam BigDecimal amount,
                           @AuthenticationPrincipal UserDetails userDetails, // Get the authenticated principal
                           Model model, // Keep Model for errors directly on dashboard
                           RedirectAttributes redirectAttributes) {
        if (userDetails == null) return "redirect:/login";
        Account fromAccount = accountService.findByUsername(userDetails.getUsername()); // Get the sender's account

        try {
            accountService.transferAmount(fromAccount, toUsername, amount);
            redirectAttributes.addFlashAttribute("successMessage", "Transfer successful!");
        } catch (RuntimeException e) { // Catches InsufficientFunds, RecipientNotFound, IllegalArgument
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            // model.addAttribute("account", fromAccount); // For re-displaying dashboard with error
            // model.addAttribute("errorMessage", e.getMessage());
            // return "dashboard"; // If not redirecting
        }
        return "redirect:/dashboard";
    }
}