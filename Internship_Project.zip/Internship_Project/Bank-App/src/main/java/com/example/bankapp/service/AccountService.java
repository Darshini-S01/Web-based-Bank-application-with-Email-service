package com.example.bankapp.service;

import com.example.bankapp.dto.AccountDto; // Import the DTO
import com.example.bankapp.model.Account;
import com.example.bankapp.model.Transaction;
import com.example.bankapp.repository.AccountRepository;
import com.example.bankapp.repository.TransactionRepository;
import com.example.bankapp.service.mail.EmailService; // Import EmailService
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // For transactional operations

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID; // For transaction reference

@Service
public class AccountService implements UserDetailsService {

    private final PasswordEncoder passwordEncoder;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final EmailService emailService; // Inject EmailService

    @Autowired
    public AccountService(PasswordEncoder passwordEncoder,
                          AccountRepository accountRepository,
                          TransactionRepository transactionRepository,
                          EmailService emailService) { // Add EmailService to constructor
        this.passwordEncoder = passwordEncoder;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.emailService = emailService; // Initialize EmailService
    }

    public Account findByUsername(String username) {
        return accountRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Account not found for username: " + username)); // More specific exception
    }

    // Overload or create a new method to find by email if needed for checks
    public boolean DtoByEmailExists(String email) {
        return accountRepository.findByEmail(email).isPresent();
    }
    public boolean DtoByUsernameExists(String username) {
        return accountRepository.findByUsername(username).isPresent();
    }


    @Transactional // Make registration transactional
    public Account registerAccount(AccountDto accountDto) {
        // Check if username already exists
        if (accountRepository.findByUsername(accountDto.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username '" + accountDto.getUsername() + "' already exists!");
        }
        // Check if email already exists
        if (accountRepository.findByEmail(accountDto.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email '" + accountDto.getEmail() + "' is already registered!");
        }

        Account account = new Account();
        account.setUsername(accountDto.getUsername());
        account.setEmail(accountDto.getEmail()); // Set the email
        account.setPassword(passwordEncoder.encode(accountDto.getPassword())); // Encode password
        account.setBalance(BigDecimal.ZERO);
        // Set default authorities if your Account entity expects them directly,
        // or if they are managed separately, ensure that logic is in place.
        // account.setAuthorities(authorities()); // If Account entity stores authorities

        Account savedAccount = accountRepository.save(account);

        // Send welcome email
        // Ensure the ID is populated after save for getAccountNumber() if it depends on ID
        // (Hibernate populates ID after save)
        emailService.sendWelcomeEmail(savedAccount);

        return savedAccount;
    }

    @Transactional
    public void deposit(Account account, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive.");
        }
        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);

        Transaction transaction = new Transaction(amount, "Deposit", LocalDateTime.now(), account);
        transactionRepository.save(transaction);
    }

    @Transactional
    public void withdraw(Account account, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive.");
        }
        if (account.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient funds");
        }
        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);

        Transaction transaction = new Transaction(amount, "Withdrawal", LocalDateTime.now(), account);
        transactionRepository.save(transaction);
    }

    public List<Transaction> getTransactionHistory(Account account) {
        return transactionRepository.findByAccountId(account.getId());
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Account account = accountRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));

        // Use the authorities stored in/associated with the Account entity if available
        // For now, using the static method as in your original code.
        // Collection<? extends GrantedAuthority> userAuthorities = account.getAuthorities();
        // if (userAuthorities == null || userAuthorities.isEmpty()) {
        //     userAuthorities = authorities(); // Fallback to default
        // }

        return new org.springframework.security.core.userdetails.User(
                account.getUsername(),
                account.getPassword(),
                authorities() // Or account.getAuthorities() if persisted with Account
        );
    }

    // This method provides default authorities.
    // Consider if authorities should be linked to the Account entity itself.
    public Collection<? extends GrantedAuthority> authorities() {
        return Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
    }

    @Transactional
    public void transferAmount(Account fromAccount, String toUsername, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive.");
        }
        if (fromAccount.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient funds for transfer.");
        }
        if (fromAccount.getUsername().equalsIgnoreCase(toUsername)) {
            throw new IllegalArgumentException("Cannot transfer funds to the same account.");
        }

        Account toAccount = accountRepository.findByUsername(toUsername)
                .orElseThrow(() -> new UsernameNotFoundException("Recipient account '" + toUsername + "' not found."));

        // Perform the transfer
        fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
        accountRepository.save(fromAccount);

        toAccount.setBalance(toAccount.getBalance().add(amount));
        Account savedToAccount = accountRepository.save(toAccount); // Get the saved recipient account

        // Generate a unique transaction reference
        String transactionReference = UUID.randomUUID().toString().substring(0, 12).toUpperCase();

        Transaction debitTransaction = new Transaction(
                amount,
                "Transfer Out to " + toAccount.getAccountHolderName() + " (Ref: " + transactionReference + ")", // Use getAccountHolderName()
                LocalDateTime.now(),
                fromAccount
        );
        transactionRepository.save(debitTransaction);

        Transaction creditTransaction = new Transaction(
                amount,
                "Transfer In from " + fromAccount.getAccountHolderName() + " (Ref: " + transactionReference + ")", // Use getAccountHolderName()
                LocalDateTime.now(),
                toAccount
        );
        transactionRepository.save(creditTransaction);

        // Send notification email to the recipient
        // Pass the 'fromAccount' (sender) and 'savedToAccount' (recipient with updated balance)
        emailService.sendTransactionNotificationEmail(savedToAccount, fromAccount, amount, transactionReference);
    }
}