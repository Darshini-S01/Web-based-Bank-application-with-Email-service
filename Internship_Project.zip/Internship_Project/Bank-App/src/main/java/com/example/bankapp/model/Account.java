package com.example.bankapp.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email; // For email validation
import jakarta.validation.constraints.NotBlank; // For ensuring email is not blank
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

@Entity
@Table(name = "accounts") // Good practice to explicitly name the table
public class Account implements UserDetails { // Ensure UserDetails methods are fully implemented if Spring Security uses them directly

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true) // Assuming username should be unique and not null
    @com.example.bankapp.model.NotBlank(message = "Username cannot be blank")
    private String username; // This is often used as accountHolderName or similar for display

    @Column(nullable = false)
    @NotBlank(message = "Password cannot be blank")
    private String password;

    @Column(nullable = false, unique = true) // Make email unique and not null
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Please provide a valid email address") // Basic email format validation
    private String email;

    @Column(precision = 19, scale = 2) // Good for currency
    private BigDecimal balance;

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true) // Consider cascade options
    private List<Transaction> transactions;

    @Transient // Authorities are typically not persisted directly with the user in this manner
    private Collection<? extends GrantedAuthority> authorities;

    // Default constructor - JPA requirement
    public Account() {
        this.balance = BigDecimal.ZERO; // Initialize balance
    }

    // Constructor for new user registration (example)
    public Account(String username, String password, String email) {
        this.username = username;
        this.password = password; // Password should be encoded before saving
        this.email = email;
        this.balance = BigDecimal.ZERO; // New accounts start with zero balance
    }


    // Constructor with all fields (ensure authorities handling is correct for your setup)
    public Account(String username, String password, String email, BigDecimal balance, List<Transaction> transactions, Collection<? extends GrantedAuthority> authorities) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.balance = balance;
        this.transactions = transactions;
        this.authorities = authorities;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    // Renaming username to accountHolderName might be clearer for display purposes if 'username' is purely for login
    // For now, we'll stick to 'username' as per your original field.
    public String getAccountHolderName() { // Convenience getter for display
        return username;
    }

    public String getUsername() { return username; } // This is for UserDetails (login)
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }

    public List<Transaction> getTransactions() { return transactions; }
    public void setTransactions(List<Transaction> transactions) { this.transactions = transactions; }

    // --- UserDetails methods ---
    // You might need to implement these more fully depending on your SecurityConfig
    // For now, assuming simple setup.
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // If you store roles, load them here. For a simple app, you might return a default role.
        // Example: return List.of(new SimpleGrantedAuthority("ROLE_USER"));
        return authorities; // Using the transient field you had
    }

    public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
        this.authorities = authorities;
    }

    // Typically, for a bank app, accounts are always enabled unless explicitly disabled.
    @Override
    public boolean isAccountNonExpired() {
        return true; // Or add a field for this
    }

    @Override
    public boolean isAccountNonLocked() {
        return true; // Or add a field for this
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true; // Or add a field for this
    }

    @Override
    public boolean isEnabled() {
        return true; // Or add a field for this
    }

    // Method to generate a unique account number (if not using ID directly)
    // This is just a placeholder; you'd need a more robust generation strategy
    public String getAccountNumber() {
        // For simplicity, using ID. In a real system, you'd generate a proper account number.
        // It could be a separate field in the database.
        return "ACC" + String.format("%010d", this.id);
    }
}