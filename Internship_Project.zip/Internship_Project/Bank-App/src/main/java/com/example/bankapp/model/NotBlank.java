package com.example.bankapp.model;

public @interface NotBlank {
    String message();
}
