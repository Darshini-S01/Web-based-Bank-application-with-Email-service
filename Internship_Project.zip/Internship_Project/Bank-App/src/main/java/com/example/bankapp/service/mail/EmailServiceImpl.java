// src/main/java/com/example/bankapp/service/mail/EmailServiceImpl.java
package com.example.bankapp.service.mail;

import com.example.bankapp.model.Account;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine; // Use spring6 for Spring Boot 3+

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;

@Service
public class EmailServiceImpl implements EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private SpringTemplateEngine templateEngine;

    @Value("${app.mail.from}")
    private String mailFrom;

    @Value("${spring.mail.username}")
    private String mailUsername;


    private void sendHtmlEmail(String to, String subject, String templateName, Context context) {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage,
                    MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
                    StandardCharsets.UTF_8.name());

            String htmlContent = templateEngine.process(templateName, context);

            // If mailFrom is not set or empty, use spring.mail.username
            String effectiveMailFrom = (mailFrom != null && !mailFrom.isEmpty()) ? mailFrom : mailUsername;


            helper.setTo(to);
            helper.setSubject(subject);
            helper.setFrom(effectiveMailFrom);
            helper.setText(htmlContent, true); // true = isHtml

            javaMailSender.send(mimeMessage);
            logger.info("HTML email sent successfully to {}", to);

        } catch (MessagingException e) {
            logger.error("Error sending HTML email to {}: {}", to, e.getMessage());
            // Consider re-throwing a custom exception or handling it more gracefully
        }
    }

    @Override
    @Async // To send emails asynchronously
    public void sendWelcomeEmail(Account account) {
        if (account.getEmail() == null || account.getEmail().isEmpty()) {
            logger.warn("Cannot send welcome email: email address is missing for account holder {}", account.getAccountHolderName());
            return;
        }
        Context context = new Context();
        context.setVariable("username", account.getAccountHolderName());
        context.setVariable("accountNumber", account.getAccountNumber());

        sendHtmlEmail(account.getEmail(), "Welcome to Our Bank!", "email/welcome-email", context);
    }

    @Override
    @Async // To send emails asynchronously
    public void sendTransactionNotificationEmail(Account recipientAccount, Account senderAccount, BigDecimal amount, String transactionReference) {
        if (recipientAccount.getEmail() == null || recipientAccount.getEmail().isEmpty()) {
            logger.warn("Cannot send transaction notification: recipient email address is missing for account holder {}", recipientAccount.getAccountHolderName());
            return;
        }
        Context context = new Context();
        context.setVariable("recipientName", recipientAccount.getAccountHolderName());
        context.setVariable("senderName", senderAccount.getAccountHolderName()); // Or sender's email if preferred
        context.setVariable("amount", amount);
        context.setVariable("transactionReference", transactionReference);
        context.setVariable("recipientAccountNumber", recipientAccount.getAccountNumber());


        sendHtmlEmail(recipientAccount.getEmail(), "You've Received Funds!", "email/transaction-notification-email", context);
    }
}
